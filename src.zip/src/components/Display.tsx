import React from 'react';
import { useSelector } from 'react-redux';
import type { RootState } from '../redux/store';

const Display: React.FC = () => {
  const { currentInput, previousInput, operator, error } = useSelector((state: RootState) => state.calculator);

  // Determine what to display
  const displayValue = error || currentInput || '0';
  
  // Show the calculation in progress
  const calculation = operator ? `${previousInput} ${operator} ${currentInput || ''}` : '';

  return (
    <div className="calculator-display-container">
      {calculation && <div className="calculation-preview">{calculation}</div>}
      <output className="calculator-display">
        {displayValue}
      </output>
    </div>
  );
};

export default Display;
