import { createSlice } from '@reduxjs/toolkit';
import type { PayloadAction } from '@reduxjs/toolkit';

interface CalculatorState {
  currentInput: string;
  previousInput: string;
  operator: '+' | '-' | '×' | '÷' | null;
  result: number | null;
  error: string | null;
}

const initialState: CalculatorState = {
  currentInput: '',
  previousInput: '',
  operator: null,
  result: null,
  error: null,
};

const calculatorSlice = createSlice({
  name: 'calculator',
  initialState,
  reducers: {
    inputNumber: (state, action: PayloadAction<string>) => {
      state.currentInput += action.payload;
    },
    inputDecimal: (state) => {
      if (!state.currentInput.includes('.')) {
        state.currentInput = state.currentInput === '' ? '0.' : state.currentInput + '.';
      }
    },
    setOperator: (state, action: PayloadAction<'+' | '-' | '×' | '÷'>) => {
      state.operator = action.payload;
      state.previousInput = state.currentInput;
      state.currentInput = '';
    },
    calculate: (state) => {
      if (!state.previousInput || !state.currentInput || !state.operator) {
        return;
      }

      const prev = parseFloat(state.previousInput);
      const current = parseFloat(state.currentInput);
      
      try {
        let calculatedResult: number;
        
        switch (state.operator) {
          case '+':
            calculatedResult = prev + current;
            break;
          case '-':
            calculatedResult = prev - current;
            break;
          case '×':
            calculatedResult = prev * current;
            break;
          case '÷':
            if (current === 0) {
              throw new Error('Division by zero');
            }
            calculatedResult = prev / current;
            break;
          default:
            return;
        }
        
        state.result = calculatedResult;
        state.currentInput = calculatedResult.toString();
        state.previousInput = '';
        state.operator = null;
        state.error = null;
      } catch (error) {
        state.error = error instanceof Error ? error.message : 'Unknown error';
      }
    },
    clear: (state) => {
      return initialState;
    },
    clearEntry: (state) => {
      state.currentInput = '';
      state.error = null;
    },
    toggleSign: (state) => {
      if (state.currentInput) {
        state.currentInput = state.currentInput.charAt(0) === '-' 
          ? state.currentInput.substring(1) 
          : '-' + state.currentInput;
      }
    },
    inputPercent: (state) => {
      if (state.currentInput) {
        const value = parseFloat(state.currentInput) / 100;
        state.currentInput = value.toString();
      }
    }
  },
});

export const { 
  inputNumber,
  inputDecimal,
  setOperator,
  calculate,
  clear,
  clearEntry,
  toggleSign,
  inputPercent
} = calculatorSlice.actions;

export default calculatorSlice.reducer;
